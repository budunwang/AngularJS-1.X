var app = angular.module('myApp', []);
	
app.controller('siteCtrl', function($scope, $http) {
  $http({
    method:'GET',
    url:'data.json'
  }).then(function(success){
    console.log(success);
    $scope.user_data=success.data;
  },
  function(error){
    
  });
});


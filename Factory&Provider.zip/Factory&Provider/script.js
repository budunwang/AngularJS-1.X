var app = angular.module('myApp', []);

app.config(function(dataProvider){
  dataProvider.setPrefix();  
});

//Provider
app.provider('data',function(){
  this.$get=function() {
    var prefix="";
    if(prefixCheck) {
      prefix="Mr";
    }
    
    return {
      "firstname":"Tom",
      "lastname":"Cat",
      "format_name":function() {
        return prefix+" "+this.firstname+","+this.lastname;
      }
    };
  };
  
  var prefixCheck=false;
  this.setPrefix=function() {
    prefixCheck=true;
  };
});

//factory
app.factory('datafactory',function(){
  return {
    "add":function(x,y) {
      return x+y;
    },
    "multiply":function(x,y) {
      return x*y;
    }
  };
});

app.controller("siteCtrl",function($scope,data,datafactory){
  $scope.username=data.format_name();
  $scope.num=datafactory.add(2,3);
});




var app = angular.module('myApp', []);

//factory
app.factory('datafactory',function($q){
  return {
    'testFn':function() {
      var myPromise=$q.defer();
      setTimeout(function(){
        myPromise.resolve("Hello world");
      },3000);
      return myPromise.promise;
    }
  };
});

app.controller("siteCtrl",function($scope,datafactory){
  datafactory.testFn().then(function(success){
    //console.log(success);
    $scope.Hello=success;
  });
});

